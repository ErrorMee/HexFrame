//
//  MeiPaiConnector.h
//  ShareSDKConnector
//
//  Created by anplex_yy on 16/12/14.
//  Copyright © 2016年 mob. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MeiPaiConnector : NSObject

@end
	

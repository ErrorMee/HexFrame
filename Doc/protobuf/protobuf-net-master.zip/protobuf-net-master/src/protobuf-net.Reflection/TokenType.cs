﻿namespace ProtoBuf.Reflection
{
    internal enum TokenType
    {
        None,
        Whitespace,
        StringLiteral,
        AlphaNumeric,
        Symbol
    }
}
